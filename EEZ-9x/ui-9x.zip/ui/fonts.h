#ifndef EEZ_LVGL_UI_FONTS_H
#define EEZ_LVGL_UI_FONTS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

extern const lv_font_t ui_font_bebas_120;


#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_FONTS_H*/