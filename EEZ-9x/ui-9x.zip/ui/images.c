#include "images.h"

const ext_img_desc_t images[2] = {
    { "Server_bmp", &img_server_bmp },
    { "WiFi-small", &img_wi_fi_small },
};
